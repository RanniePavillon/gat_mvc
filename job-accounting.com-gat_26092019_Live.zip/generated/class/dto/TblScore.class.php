<?php
	/**
	 * Object represents table 'tbl_score'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2017-11-10 07:15	 
	 */
	class TblScore{
		
		var $id;
		var $userId;
		var $cTotal;
		var $oTotal;
		var $rTotal;
		var $eTotal;
		var $overallTotal;
		var $dateCreated;
		var $dateModified;
		
	}
?>