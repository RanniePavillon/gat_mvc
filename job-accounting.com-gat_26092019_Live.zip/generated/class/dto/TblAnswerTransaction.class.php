<?php
	/**
	 * Object represents table 'tbl_answer_transaction'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2017-11-10 07:15	 
	 */
	class TblAnswerTransaction{
		
		var $id;
		var $userId;
		var $status;
		var $dateCreated;
		var $dateModified;
		
	}
?>