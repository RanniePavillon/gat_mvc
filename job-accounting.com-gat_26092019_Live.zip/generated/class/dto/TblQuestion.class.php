<?php
	/**
	 * Object represents table 'tbl_question'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2017-11-10 07:15	 
	 */
	class TblQuestion{
		
		var $id;
		var $question;
		var $lowerRate;
		var $higherRate;
		var $dateCreated;
		var $dateModified;
		
	}
?>