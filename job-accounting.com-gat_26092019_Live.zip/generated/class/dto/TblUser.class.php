<?php
	/**
	 * Object represents table 'tbl_user'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2017-11-10 07:15	 
	 */
	class TblUser{
		
		var $id;
		var $username;
		var $password;
		var $dateCreated;
		var $dateModified;
		
	}
?>