<?php
	/**
	 * Object represents table 'tbl_admin'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2017-11-10 07:23	 
	 */
	class TblAdmin{
		
		var $id;
		var $username;
		var $password;
		var $type;
		var $dateCreated;
		var $dateModified;
		
	}
?>