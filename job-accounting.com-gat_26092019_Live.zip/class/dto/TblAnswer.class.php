<?php
	/**
	 * Object represents table 'tbl_answer'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2017-11-10 07:23	 
	 */
	class TblAnswer{
		
		var $id;
		var $answerTransactionId;
		var $questionId;
		var $answer;
		var $dateCreated;
		var $dateModified;
		
	}
?>