<?php
	/**
	 * Object represents table 'tbl_user'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2017-11-10 07:23	 
	 */
	class TblUser{
		
		var $id;
		var $firstName;
		var $middleInitial;
		var $lastName;
		var $emailAddress;
		var $contactNumber;
		var $appliedPosition;
		var $dateCreated;
		var $dateModified;
		
	}
?>