<?php
/**
 * Class that operate on table 'tbl_answer_transaction'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2017-10-13 03:17
 */
class TblAnswerTransactionMySqlExtDAO extends TblAnswerTransactionMySqlDAO{

	
}
?>